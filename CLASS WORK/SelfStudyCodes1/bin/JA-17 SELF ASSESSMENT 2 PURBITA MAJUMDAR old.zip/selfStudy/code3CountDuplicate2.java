package selfStudy2;

import java.util.Scanner;

public class code3CountDuplicate2 
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("enter length of array : ");
		int n=sc.nextInt();
		char[] arr=new char[n];
		System.out.println("enter elements of array : ");
		for(int i=0;i<arr.length;i++)
		{
			arr[i]=sc.next().trim().charAt(0);
		}
		int[] dup=new int[5];
		int count;
		for(int i=0;i<arr.length;i++)
		{
			count=1;
			for(int j=i+1;j<arr.length;j++)
			{
				if(arr[i]==arr[j])
				{
					count++;
				}
			}
			dup[i]=count;
		}
		count=0;
		System.out.println("the duplicate integers are : ");
		for(int i=0;i<arr.length;i++)
		{
			if(dup[i]>1)
			{
				System.out.println(arr[i]);
				count++;
			}
		}
		System.out.println("number of duplicated values are : "+count);
		
	}
}
